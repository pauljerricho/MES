<link rel="stylesheet" href="/css/datatable.css">
<link rel="stylesheet" href="/css/responsive.dataTables.min.css">
<link rel="stylesheet" href="/css/dataTables.semanticui.min.css">
<script src="/js/jquery.dataTables.min.js"></script>
<script src="/js/dataTables.responsive.min.js"></script>