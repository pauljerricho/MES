<script src="/trans_js/?mod=header&ajax_link_page=/header.php"></script>
<div id="top">
    <h3>
        <a class="fontstyle" href="index.php">ABOUT ANIMAL</a>
        <img src="./img/doglogo.png" width="25px" height="20px">
    </h3>
    <ul id="top_menu">   
        <li><a class="fontstyle" href="introduce.php" >ABOUT US</a></li>
        <li> | </li>
        <li><a class="fontstyle" href="mem_form.php">REGISTER</a> </li>
        <li> | </li>
        <li><a class="fontstyle" href="lgi_form.php">LOG IN</a></li>
        <li> | </li>
        <li class="fontstyle">logged</li>
        <li> | </li>
        <li><a class="fontstyle" href="introduce.php">ABOUT US</a></li>
        <li> | </li>
        <li><a class="fontstyle" href="mem_modify_form.php">MODIFY</a></li>
        <li> | </li>
        <li><a class="fontstyle" href="#">LOGOUT</a></li>
        <li> | </li>
        <li><a href="admin_member.php" class="fontstyle">ADMIN</a></li>
    </ul>
</div>
<div id="menu_bar" style="align-contents: center" >
    <ul class="fontstyle">  
        <li><a href="index.php" class="back"
         style="margin-left : 100px">HOME</a></li>
        <li><a href="msg_form.php" class="back" >MESSAGE</a></li>                                
        <li><a href="bd_list.php" class="back">BOARD</a></li>
        <li><a href="index.php" class="back"
         style="margin-right : 100px">EVENT</a>
    </ul>
</div>