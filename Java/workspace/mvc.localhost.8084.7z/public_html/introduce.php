<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>MYUNGLI 실습예제</title>
<?php include "head.php";?>
<link rel="stylesheet" type="text/css" href="./css/main.css">
</head>
<body> 
	<header>
    	<?php include "header.php";?>
    </header>
    <div style="text-align: center;font-family : 'Nanum Pen Script'; font-size : 3em;" ><br>동물을 사랑하는 마음으로....</div><br>
    <br><br><div style="display : inline-block;">
         <img alt="강아지2" src="./img/dog2.jpg" width="20%" height="60%" style="border-radius : 60%; float : left; position : relative; left : 200px; box-shadow : 0px 0px 50px yellow; ">
         
         <div style="float : right;font-family : 'Nanum Pen Script';font-size : 25px; text-align : left; float : left; position : relative; left : 250px"><br>반려동물은 함께 공존하는 친구이자 가족입니다.
         <br>그들이 우리를 위해 조건없는 사랑을 주듯이, 저희도 그들에게 사랑으로 보답해야할 때 입니다.
         <br>저희는 사람들이 동물들에게 좀 더 친근하게 다가갈 수 있도록 하고자 이 사업을 시작하였습니다.
         <br>회사 수익의 일부를 유기동물단체에 기부하고, 유기동물 관련 자원봉사 신청도 받고 있습니다.
         <br>세상 모든 동물들이 행복해지는 그 날까지 노력하겠습니다. 감사합니다.</div>
         
           </div>
    </body><br>
    <footer>
    <?php include "footer.php";?>
    </footer>
   </html>