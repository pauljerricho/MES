<div><img src="./img/myungli_image.png" alt="myungli_image" style="width : 100%;height : 100%"></div>
<link rel="stylesheet" type="text/css" href="./css/font.css">
<div id="main_content" class="fontstyle">
    <div id="latest">
        <h4>자유 게시판  <a href="bd_list.php" style="float : right;">  >> 더 보기</a></h4>
        <ul>
            <li>
                <span>subject</span>
                <span>name</span>
                <span>regist_day</span> 
            </li>
		</ul>
    </div>
    <div id="point_rank">
        <h4 style="text-align: center">마일리지 순위</h4>
        <ul>
            <li>
                <span>rank</span>
                <span>name</span>
                <span>id</span>
                <span>point</span>
            </li>
        </ul>
    </div>
</div>