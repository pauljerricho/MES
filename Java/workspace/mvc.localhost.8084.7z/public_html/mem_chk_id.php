<!DOCTYPE html>
<head>
<meta charset="utf-8">
<?php include "head.php";?>
<script src="/trans_js/?mod=search"></script>
<link rel="stylesheet" type="text/css" href="./css/font.css">
<style>
h3 {
	border-bottom: solid 5px black;
	padding-bottom: 5px;
}

#close {
	margin: 20px 0 0 80px;
	cursor: pointer;
}

ul {list-style-type: none;margin: 10px 10px 20px 10px;}
</style>
</head>
<body class="fontstyle">
	<h3>아이디 중복체크</h3>
	<p></p>
	<div style="margin-left: 90px; cursor: pointer; border: 5px solid gray; margin-right: 90px; width: 55px; height: 20px">CLOSE</div>
	</div>
</body>
</html>