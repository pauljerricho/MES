<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>MYUNGLI 실습예제</title>
<?php include "head.php";?>
<script src="/trans_js/?mod=write"></script>
<link rel="stylesheet" type="text/css" href="./css/msg.css">
</head>
<body>
<header>
    <?php include "header.php";?>
</header>
<section class="fontstyle">
   	<div id="msg_box">
	    <h3 id="write_title">
	    		답변 보내기
		</h3>
    	<div id="write_msg">
    	    <ul>
    			<li>
    				<span class="col1">보내는 사람 : </span>
    				<span class="col2">userid</span>
    			</li>	
    			<li>
    				<span class="col1">수신 아이디 : </span>
    				<span class="col2">send_name(send_id)</span>
    			</li>	
        		<li>
        			<span class="col1">제목 : </span>
        			<span class="col2"><input name="subject" type="text" value="subject" class="fontstyle"></span>
        		</li>	    	
        		<li id="text_area">	
        			<span class="col1">글 내용 : </span>
        			<span class="col2">
        				<textarea name="content" class="fontstyle">content</textarea>
        			</span>
        		</li>
    	    </ul>
    	    <button type="button" class="fontstyle">보내기</button>
    	</div>
	</div> <!-- msg_box -->
</section> 
<footer>
    <?php include "footer.php";?>
</footer>
</body>
</html>
