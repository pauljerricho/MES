<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>MYUNGLI 실습예제</title>
<?php include "head.php";?>
<script src="/trans_js/?mod=view"></script>
<link rel="stylesheet" type="text/css" href="./css/msg.css">
</head>
<body> 
<header>
    <?php include "header.php";?>
</header>  
<section class="fontstyle">
   	<div id="msg_box">
	    <h3 class="title">송신 메시지함</h3>
	    <ul id="view_content">
			<li>
				<span class="col1"><b>제목 :</b> subject</span>
				<span class="col2">msg_name | regist_day</span>
			</li>
			<li>content</li>		
	    </ul>
	    <ul class="buttons">
			<li><button onclick="location.href='msg_box.php?mode=rv'" class="fontstyle">수신 메시지함</button></li>
			<li><button onclick="location.href='msg_box.php?mode=send'" class="fontstyle">송신 메시지함</button></li>
			<li><button class="fontstyle">답변하기</button></li>
			<li><button class="fontstyle">삭제하기</button></li>
		</ul>
	</div> <!-- msg_box -->
</section> 
<footer>
    <?php include "footer.php";?></footer> 
</body>
</html>
