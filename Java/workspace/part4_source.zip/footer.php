        <div id="footer_content">
            <div id="footer_logo"><img src="./img/logo.png" alt="myungli_logo"></div>
            <ul id="download">
                <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;company. (주)명리 owner. 이유준 fax. 02) 718-1812 tel. 02) 3211-6600 business license. 105-86-27477</li>
                <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;online license. 제2015-서울영등포 0616호 address. 서울특별시 영등포구 당산로 41길 11(당산동4가) SK V1center E동 B114호</li>
            </ul>
        </div>