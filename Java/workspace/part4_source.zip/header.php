<link rel="stylesheet" type="text/css" href="./css/font.css">
<link rel="stylesheet" type="text/css" href="./css/hover.css">
<div id="top">
    <h3>
        <a class="fontstyle" href="index.php">ABOUT ANIMAL</a>
        <img src="./img/doglogo.png" width="25px" height="20px">
    </h3>
    <ul id="top_menu">          
   <ul>
        <li><a class="fontstyle" href="introduce.php" >ABOUT US</a></li>
        <li> | </li>
        <li><a class="fontstyle" href="mem_form.php">REGISTER</a> </li>
        <li> | </li>
        <li><a class="fontstyle" href="lgi_form.php">LOG IN</a></li>
    </ul>
        <li class="fontstyle"><?=$logged?> </li>&nbsp;
        <li><a class="fontstyle" href="introduce.php">ABOUT US</a></li>
        <li> | </li>
        <li><a class="fontstyle" href="lgout.php">LOGOUT</a></li>
        <li> | </li>
        <li><a class="fontstyle" href="mem_modify_form.php">MODIFY</a></li>
        <li> | </li>
        <li><a href="admin_member.php" class="fontstyle">ADMIN</a></li>
    </ul>
</div>
<div id="menu_bar" style="align-contents: center" >
    <ul class="fontstyle">  
        <li><a href="index.php" class="back"
         style="margin-left : 100px">HOME</a></li>
        <li><a href="msg_form.php" class="back" >MESSAGE</a></li>                                
        <li><a href="bd_list.php" class="back">BOARD</a></li>
        <li><a href="index.php" class="back"
         style="margin-right : 100px">EVENT</a>
    </ul>
</div>