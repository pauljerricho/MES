<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>MYUNGLI 실습예제</title>
<link rel="stylesheet" type="text/css" href="./css/common.css">
<link rel="stylesheet" type="text/css" href="./css/main.css">
<link rel="stylesheet" type="text/css" href="./css/font.css">
</head>
<body> 
	<header>
    	<?php include "header.php";?>
    </header>
	<section class="fontstyle">
	    <?php include "main.php";?>
	</section> 
	<footer>
    	<?php include "footer.php";?>
    </footer>
</body>
</html>
