<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>MYUNGLI 실습예제</title>
<link rel="stylesheet" type="text/css" href="./css/common.css">
<link rel="stylesheet" type="text/css" href="./css/member.css">
<link rel="stylesheet" type="text/css" href="./css/font.css">
</head>
<body> 
	<header>
    	<?php include "header.php";?>
    </header>
	<section class="fontstyle">
	
        <div  id="main_content">
      		<div id="join_box">
          	<form  name="mem_form" method="post" action="mem_insert.php">
          		<input type="hidden" name="id_dup">
			    <h2>회원 가입</h2>
    		    	<div class="form id">
				        <div class="col1">아이디</div>
				        <div class="col2">
							<input type="text" name="id" class="fontstyle">
				        </div>  
				        <div class="col3">
				        	<a href="#"><div onclick="check_id()" style="border : medium solid gray;border-radius : 10px;font-size : 12px">중복확인</div></a>
				        </div>                 
			       	</div>
			       	<div class="clear"></div>

			       	<div class="form">
				        <div class="col1">비밀번호</div>
				        <div class="col2">
							<input type="password" name="pass" class="fontstyle" >
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">비밀번호 확인</div>
				        <div class="col2">
							<input type="password" name="pass_confirm" class="fontstyle" >
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="form">
				        <div class="col1">이름</div>
				        <div class="col2">
							<input type="text" name="name" class="fontstyle" >
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="form email">
				        <div class="col1">이메일</div>
				        <div class="col2">
							<input type="text" name="email1" class="fontstyle">@<input type="text" name="email2" class="fontstyle">
				        </div>                 
			       	</div>
			       	<div class="clear"></div>
			       	<div class="bottom_line"> </div>
			       	<div class="buttons">
			       	<input type="submit" value="저장" style="width : 70px;border : medium solid gray; cursor : pointer;" class="fontstyle" >
                  		<input type="reset" value="취소" style="width : 70px;border : medium solid gray; cursor : pointer;" class="fontstyle" >
	           		</div>
           	</form>
        	</div> <!-- join_box -->
        </div> <!-- main_content -->
	</section> 
	<footer>
    	<?php include "footer.php";?>
    </footer> 
</body>
</html>

