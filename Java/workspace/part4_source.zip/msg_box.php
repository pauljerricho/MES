<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>MYUNGLI 실습예제</title>
<link rel="stylesheet" type="text/css" href="./css/common.css">
<link rel="stylesheet" type="text/css" href="./css/msg.css">
<link rel="stylesheet" type="text/css" href="./css/font.css">
</head>
<body> 
<header>
    <?php include "header.php";?>
</header>  
<section class="fontstyle">
	
   	<div id="msg_box">
	    <h3>송신 메시지함</h3>
	    <div>
	    	<ul id="message">
				<li>
					<span class="col1">번호</span>
					<span class="col2">제목</span>
					<span class="col3">받은이</span>
					<span class="col4">등록일</span>
				</li>
				<li>
					<span class="col1">article_num</span>
					<span class="col2"><a href="msg_view.php?mode=mode&num=num">subject</a></span>
					<span class="col3">msg_name(msg_id)</span>
					<span class="col4">regist_day</span>
				</li>
				<li>
					<div style="text-align:center;">수신된 메시지가 없습니다.</div>
				</li>
	    	</ul>
			<ul id="page_num"> 	
				<li>1</li>
			</ul> <!-- page -->	    	
			<ul class="buttons">
				<li><button  class="fontstyle" onclick="location.href='msg_box.php?mode=rv'">수신 메시지함</button></li>
				<li><button  class="fontstyle" onclick="location.href='msg_box.php?mode=send'">송신 메시지함</button></li>
				<li><button  class="fontstyle" onclick="location.href='msg_form.php'">메시지 전송</button></li>
			</ul>
	</div> <!-- msg_box -->
</section> 
<footer>
    <?php include "footer.php";?> -->
</footer>
</body>
</html>
